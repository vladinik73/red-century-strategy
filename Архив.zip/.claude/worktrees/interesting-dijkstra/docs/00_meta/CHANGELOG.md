# Changelog

## v4.12.1 — Phase 4.5.1 (Broken Link Fix)

- Исправлена битая ссылка в `docs/06_combat/Siege_Effects.md`:
  `docs/02_cities/City_Defense.md` → `docs/04_economy/City_Defense.md`

---

## v4.12 — Phase 4.5 (Schema: Match State)

- `schemas/match.schema.json` — обновлён до Canonical State Container (полный game state) + `events[]` как replay-log.
- `docs/00_meta/SOURCE_OF_TRUTH.md` — добавлена секция Match State Schema (v4.12).
- `schemas/README.md` и `docs/00_meta/REPO_STRUCTURE.md` — обновлены ссылками на match schema.

---

## v4.11 — Phase 4.4 (Start Conditions + Schema: Player)

- Добавлен канонический документ стартовых условий: `docs/01_overview/Start_Conditions.md`.
- Добавлена схема состояния игрока/цивилизации: `schemas/player.schema.json`.
- Обновлены индексы и Source of Truth под v4.11.

---

## v4.10 — Phase 4.3 (Schema: Tile)

- Добавлен `schemas/tile.schema.json` — каноническая структура тайла карты (terrain/resources/roads/ports/territory/visibility).
- Зафиксирован `MaxCivs = 10` (слоты видимости).

---

## v4.9 — Phase 4.2 (Visibility: Permanent Reveal)

- Введена каноническая модель видимости **2-state**: `UNEXPLORED` / `VISIBLE` (fog-of-war отсутствует).
- Раскрытие карты **перманентное**: открытые тайлы остаются видимыми навсегда (включая после разрыва альянса).
- Добавлено правило: у каждого юнита есть параметр `visibility`; видимость обновляется событийно (spawn/move/capture).
- Горы: `visibility +1` для юнита на горе; модель S2 "гора стоит дороже для обзора" (`cost=2`).
- Альянсы делятся видимостью полностью.

Канон: `docs/03_map/Visibility.md`

---

## v4.8.1 — Phase 4.1 (Victory timing sync)

- Синхронизирован момент проверки победы: **в конце каждого хода**, а не полного раунда.
  - `docs/08_diplomacy/Victory_Rules.md`
  - `docs/00_meta/SOURCE_OF_TRUTH.md`

---

## v4.8 — Phase 4.0 (Turn Pipeline)

- Добавлен канонический документ `docs/01_overview/Turn_Pipeline.md`, фиксирующий порядок фаз хода:
  тик таймеров → бунт → доход → расчёт ОД → действия → победные таймеры → проверка победы.

---

## v4.7 — Phase 3.6 (China Balance: Stability Trigger + Spawn Rule)

- Китай: стабильность от убийств (`+1`) теперь начисляется **только** при убийстве на своей территории или в интегрированном городе.
- Генерация карты: старт Китая не ближе **7 клеток** к краю карты (анти-«угловая черепаха»).
- Устранён эксплойт «stability farming» через агрессивную войну.

---

## v4.6 — Phase 3.5 (South Asia Balance)

- Массовый мобилизационный батальон: HP 8→7, Damage 3→2.
- Удалён бонус +1 к лимиту юнитов в городе.
- Сохранена стоимость 1 ОД для поддержания идентичности «массовой армии».

---

## v4.5.1 — Phase 3.4.1 (Hypersonic: Capital Protection)

- Восстановлено каноническое ограничение: гиперзвуковая ракета не может атаковать столицу цивилизации.

---

## v4.5 — Phase 3.4 (Hypersonic + Naval Counterplay)

- Добавлена контр-игра против флота: наземные дальнобойные юниты (Range ≥ 2) могут атаковать корабли на прибрежных клетках при наличии видимости.
- Гиперзвук теперь требует видимости клетки цели и не может атаковать корабли.
- Гиперзвук игнорирует бонусы местности, но не игнорирует городскую оборону (City Defense Level).
- Устранён сценарий безответной осады при потере порта.

---

## v4.4.1 — Phase 3.3.1 (UI sync: Serial Strike)

- `docs/10_uiux/Unit_Interaction.md` — описание серийного юнита синхронизировано с каноном v4.4 (SerialKillCap, DamageMultiplierPerKill, условия остановки цепочки).

---

## v4.4 — Phase 3.3 (Serial Strike Balance)

- Серийный удар: введён лимит `SerialKillCap = 5` убийств за одну цепочку в ход.
- Деградация урона в цепочке усилена: `DamageMultiplierPerKill = 0.85` (−15% после каждого убийства).
- Устранён эксплойт бесконечной зачистки фронта одним спец‑юнитом.

---

## v4.3 — Phase 3.2 (Alliance Economic Victory Fix)

- Экономическая победа теперь считается **только по CityPower игрока** (без суммирования через альянс).
- Устранён эксплойт: победа через союз с сильнейшим ИИ без реального доминирования.
- Альянсы сохраняют экономические/боевые бонусы, но не считаются "контролем" для условия 75%.

---

## v4.2 — Phase 3.1 (Cyber Rebalance)

- Введён лимит: **1 активный «Сбой»** на цивилизацию
- Применение «Сбоя» теперь требует **1 ОД**
- Дороги больше не уничтожаются — получают статус **DamagedRoad (2 хода)**
- DamagedRoad: не учитывается в `NetworkBonus`, не даёт бонус перемещения, авто-восстанавливается (или чинится за 1 ОД)
- Устранены эксплойты массовой кибер-ротации и мгновенного обрушения магистрали

---

## v4.1 — Phase 2.1 hotfix
Дата: 2026-03-01

### Новые канонические файлы
- `docs/07_units/Cyber_Effects.md` — уточнение «Сбоя»: два параллельных эффекта (CyberPenalty -1 OD + CyberIncomeMultiplier 0.8)

### Обновлённые файлы
- `docs/04_economy/Stability_and_Morale.md` — добавлена таблица MoneyMultiplier (80–100: +5%, 60–79: 0%, 40–59: -5%, 20–39: -10%, 0–19: -20%); MoraleModifier переименован в MoraleMultiplier с таблицей значений
- `docs/06_combat/Damage_and_Rules.md` — формула урона изменена на мультипликативную: `floor((BaseDamage + TerrainBonus - DefenseModifier) × MoraleMultiplier)`; добавлена таблица MoraleMultiplier

### Консистентность
- SOURCE_OF_TRUTH обновлён до v4.1: MoneyMultiplier table, MoraleMultiplier как множитель, кибер-эффекты уточнены
- Устранена неоднозначность MoraleModifier (аддитивный → мультипликативный)
- Устранена недоопределённость MoneyMultiplier (добавлена таблица)
- Кибер-эффекты формализованы в отдельном файле с ссылками из Money_Model.md и Action_Points.md

---

## v4.0 — Phase 2 (Economy & Terrain)
Дата: 2026-03-01

### Новые канонические файлы
- `docs/04_economy/Money_Model.md` — полная формула MoneyPerTurn (базовый доход + добыча + магистраль + союзы + стабильность + осада + кибер)
- `docs/06_combat/Siege_Effects.md` — эффекты осады: -30% экономика/наука, +30% стоимость производства, -1 DefenseModifier
- `docs/07_units/Production_Rules.md` — 1 юнит/ход на интегрированный город, мгновенное появление, очередь глубиной 1

### Обновлённые файлы
- `docs/04_economy/Action_Points.md` — формализована формула ОД: база 5 + города + технологии + модификаторы (стабильность, магистраль, союзы, оккупация, кибер)
- `docs/04_economy/Stability_and_Morale.md` — уточнены штрафы (захват -2, потеря -4, столица -8, разрыв союза -2, оккупация -1/город), бунт при 0 стабильности
- `docs/05_tech/Tech_Progression.md` — SciencePerTurn формула, Research Boost (ConversionRate 0.5), связь с ОД и победой
- `docs/08_diplomacy/Diplomacy_and_Alliances.md` — лимит 2 союза, cooldown 3 хода, кибер = автовойна

### Патчи существующих файлов
- `docs/06_combat/Damage_and_Rules.md` — добавлен DefenseModifier: -1 если город под осадой (ссылка на Siege_Effects.md)
- `docs/06_combat/Siege_Air_Sea.md` — заменена дублирующая формулировка «-30% к производству» на ссылку на Siege_Effects.md
- `docs/02_cities/City_Levels.md` — добавлена секция «Производство юнитов» со ссылкой на Production_Rules.md
- `docs/04_economy/Resources.md` — уточнён тип выхода ресурсных клеток (Money/Science), условия запуска добычи, ссылки на Money_Model.md и Tech_Progression.md

### Консистентность
- SOURCE_OF_TRUTH обновлён до v4.0: добавлены секции Phase 2 (экономика, ОД, осада, стабильность, дипломатия, производство)
- Устранено дублирование определения осады между Siege_Air_Sea.md и Siege_Effects.md
- Формулы OD/Science/Money проверены на согласованность между файлами

---

## v3.0 — Phase 1 (integration)
Дата: 2026-03-01

### Победы
- Военная победа PvE: теперь ≥60% интегрированных городов (ранее: «захват всех столиц»)
- Экономическая победа: формализовано CityPower = сумма уровней; порог 75%; удержание 5 ходов
- Технологическая победа: таймер 10 ходов; сброс при захвате интегрированного города
- Победа альянса: лидер альянса — победитель; если лидер ИИ → игрок проигрывает

### Города
- Добавлена спецификация `docs/02_cities/` (City_Capture.md, City_Levels.md)
- Город = 1 клетка; интеграция = 4 хода (без изменений)
- Уровни городов: max 5, апгрейд за деньги (не ОД), стоимость: 100/200/350/550
- CityPower = сумма уровней интегрированных городов

### Технологии
- Расширена спецификация `Tech_Progression.md`: BaseCost(level) = 10 × level²
- Research Boost: ConversionRate = 0.5 (1 деньга → 0.5 науки, без лимита)
- SciencePerTurn = 5 + CityBonus + TechBonus + NetworkContribution

### AI
- Добавлена консолидированная спецификация `AI_Spec_v1_0.md`
- Определены все переменные скоринга (ProximityBonus, OpportunityScore, GrievanceScore и др.)
- Консолидированы Scoring_Model, Difficulty, Hidden_Civilization в один документ

### Консистентность
- Исправлено противоречие: «Capture all capitals» → ≥60% интегрированных городов
- SOURCE_OF_TRUTH обновлён до v3.0 с инвариантами Phase 1
- Scoring_Model.md: добавлена ссылка на AI_Spec_v1_0.md как полную спецификацию

### Удалённые файлы
- Удалены корневые legacy-файлы (01–07_*.md, RED_AGE_GDD.md, red_age_full_design_document_v_1_0.md)
- Удалена директория `docs/00_meta/legacy/`
- Единственный источник истины: `docs/`

---

## v2.6 (split)
- Разбивка спецификации на md-файлы для Cursor/Claude
- Добавлена web PvE UI/UX спецификация
- Near-future слой юнитов: дроны/гиперзвук/кибер
- Ограничения кибер-атаки на столицу и вокруг неё
- Ограничение гиперзвукового удара: 1/ход, не по столице
- Механика бунта при 0 стабильности: город становится нейтральным (без гарнизона)

Дата: 2026-03-01
