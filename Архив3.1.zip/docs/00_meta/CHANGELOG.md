# Changelog

## v4.2 — Phase 3.1 (Cyber Rebalance)

- Введён лимит: **1 активный «Сбой»** на цивилизацию
- Применение «Сбоя» теперь требует **1 ОД**
- Дороги больше не уничтожаются — получают статус **DamagedRoad (2 хода)**
- DamagedRoad: не учитывается в `NetworkBonus`, не даёт бонус перемещения, авто-восстанавливается (или чинится за 1 ОД)
- Устранены эксплойты массовой кибер-ротации и мгновенного обрушения магистрали

---

## v4.1 — Phase 2.1 hotfix
Дата: 2026-03-01

### Новые канонические файлы
- `docs/07_units/Cyber_Effects.md` — уточнение «Сбоя»: два параллельных эффекта (CyberPenalty -1 OD + CyberIncomeMultiplier 0.8)

### Обновлённые файлы
- `docs/04_economy/Stability_and_Morale.md` — добавлена таблица MoneyMultiplier (80–100: +5%, 60–79: 0%, 40–59: -5%, 20–39: -10%, 0–19: -20%); MoraleModifier переименован в MoraleMultiplier с таблицей значений
- `docs/06_combat/Damage_and_Rules.md` — формула урона изменена на мультипликативную: `floor((BaseDamage + TerrainBonus - DefenseModifier) × MoraleMultiplier)`; добавлена таблица MoraleMultiplier

### Консистентность
- SOURCE_OF_TRUTH обновлён до v4.1: MoneyMultiplier table, MoraleMultiplier как множитель, кибер-эффекты уточнены
- Устранена неоднозначность MoraleModifier (аддитивный → мультипликативный)
- Устранена недоопределённость MoneyMultiplier (добавлена таблица)
- Кибер-эффекты формализованы в отдельном файле с ссылками из Money_Model.md и Action_Points.md

---

## v4.0 — Phase 2 (Economy & Terrain)
Дата: 2026-03-01

### Новые канонические файлы
- `docs/04_economy/Money_Model.md` — полная формула MoneyPerTurn (базовый доход + добыча + магистраль + союзы + стабильность + осада + кибер)
- `docs/06_combat/Siege_Effects.md` — эффекты осады: -30% экономика/наука, +30% стоимость производства, -1 DefenseModifier
- `docs/07_units/Production_Rules.md` — 1 юнит/ход на интегрированный город, мгновенное появление, очередь глубиной 1

### Обновлённые файлы
- `docs/04_economy/Action_Points.md` — формализована формула ОД: база 5 + города + технологии + модификаторы (стабильность, магистраль, союзы, оккупация, кибер)
- `docs/04_economy/Stability_and_Morale.md` — уточнены штрафы (захват -2, потеря -4, столица -8, разрыв союза -2, оккупация -1/город), бунт при 0 стабильности
- `docs/05_tech/Tech_Progression.md` — SciencePerTurn формула, Research Boost (ConversionRate 0.5), связь с ОД и победой
- `docs/08_diplomacy/Diplomacy_and_Alliances.md` — лимит 2 союза, cooldown 3 хода, кибер = автовойна

### Патчи существующих файлов
- `docs/06_combat/Damage_and_Rules.md` — добавлен DefenseModifier: -1 если город под осадой (ссылка на Siege_Effects.md)
- `docs/06_combat/Siege_Air_Sea.md` — заменена дублирующая формулировка «-30% к производству» на ссылку на Siege_Effects.md
- `docs/02_cities/City_Levels.md` — добавлена секция «Производство юнитов» со ссылкой на Production_Rules.md
- `docs/04_economy/Resources.md` — уточнён тип выхода ресурсных клеток (Money/Science), условия запуска добычи, ссылки на Money_Model.md и Tech_Progression.md

### Консистентность
- SOURCE_OF_TRUTH обновлён до v4.0: добавлены секции Phase 2 (экономика, ОД, осада, стабильность, дипломатия, производство)
- Устранено дублирование определения осады между Siege_Air_Sea.md и Siege_Effects.md
- Формулы OD/Science/Money проверены на согласованность между файлами

---

## v3.0 — Phase 1 (integration)
Дата: 2026-03-01

### Победы
- Военная победа PvE: теперь ≥60% интегрированных городов (ранее: «захват всех столиц»)
- Экономическая победа: формализовано CityPower = сумма уровней; порог 75%; удержание 5 ходов
- Технологическая победа: таймер 10 ходов; сброс при захвате интегрированного города
- Победа альянса: лидер альянса — победитель; если лидер ИИ → игрок проигрывает

### Города
- Добавлена спецификация `docs/02_cities/` (City_Capture.md, City_Levels.md)
- Город = 1 клетка; интеграция = 4 хода (без изменений)
- Уровни городов: max 5, апгрейд за деньги (не ОД), стоимость: 100/200/350/550
- CityPower = сумма уровней интегрированных городов

### Технологии
- Расширена спецификация `Tech_Progression.md`: BaseCost(level) = 10 × level²
- Research Boost: ConversionRate = 0.5 (1 деньга → 0.5 науки, без лимита)
- SciencePerTurn = 5 + CityBonus + TechBonus + NetworkContribution

### AI
- Добавлена консолидированная спецификация `AI_Spec_v1_0.md`
- Определены все переменные скоринга (ProximityBonus, OpportunityScore, GrievanceScore и др.)
- Консолидированы Scoring_Model, Difficulty, Hidden_Civilization в один документ

### Консистентность
- Исправлено противоречие: «Capture all capitals» → ≥60% интегрированных городов
- SOURCE_OF_TRUTH обновлён до v3.0 с инвариантами Phase 1
- Scoring_Model.md: добавлена ссылка на AI_Spec_v1_0.md как полную спецификацию

### Удалённые файлы
- Удалены корневые legacy-файлы (01–07_*.md, RED_AGE_GDD.md, red_age_full_design_document_v_1_0.md)
- Удалена директория `docs/00_meta/legacy/`
- Единственный источник истины: `docs/`

---

## v2.6 (split)
- Разбивка спецификации на md-файлы для Cursor/Claude
- Добавлена web PvE UI/UX спецификация
- Near-future слой юнитов: дроны/гиперзвук/кибер
- Ограничения кибер-атаки на столицу и вокруг неё
- Ограничение гиперзвукового удара: 1/ход, не по столице
- Механика бунта при 0 стабильности: город становится нейтральным (без гарнизона)

Дата: 2026-03-01
